<?php  

    require_once("db_connect.php");

    $articles =[];
    $error ="";

    try{
        $pdo=db_connect();
        
        $sql=
            "SELECT 
            id,
            title,
            content,
            image,
            created_at 
            FROM articles ORDER by id DESC LIMIT 10";
        $stmt=$pdo->query($sql);

        $articles=$stmt->fetchAll(PDO::FETCH_ASSOC);
    }catch (PDOException $e){
        echo "エラーが発生しました:".($e->getMessage());
        exit;
    }


?> 

   <!DOCTYPE html>
    <html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>トップページ</title>
        <link rel="stylesheet" href="./assets/css/sanitize.css">
        <link rel="stylesheet" href="./assets/css/style.css">
    </head>
    <body>
            <header>
            <?php include("./includes/header.php"); ?>
            </header>
        <div id="wrapper"> 
                <div class="main-content">
                        <?php if(!empty($articles)){?>
                            <?php  foreach($articles as $article){?>
                        <article class="card">
                            <?php if($article["image"]){ ?>
                                <img src="images/<?php echo ($article["image"]);?>"
                                alt="<?php echo ($article["title"]);?>:画像" class="image">   
                        <?php } ?>
                    <div class="article-content">
                        <h2 class="article-title">
                            <a href="single.php?id=<?php echo($article["id"]);?>">
                                <?php echo ($article["title"]);?>
                            </a>
                        </h2>
                        <p class="excerpt">
                            <?php $excerpt=mb_substr($article["content"],0,100);
                                    if (mb_strlen($article["content"])>100){
                                        $excerpt.="...";
                                    } echo ($excerpt);
                            ?>
                        </p> 
                        
                        <p class="meta"><?php echo ($article["created_at"]); ?></p>
                        <p><a href="single.php?id=<?php echo($article["id"]);?>">続きを読む</a></p>
                    </div>
                        </article>
                            <?php } ?>
                        <?php } ?>
                        
                        
                </div>
        </div>
            <footer>
                <?php include("./includes/footer.php"); ?>
            </footer>
            
        
    </body>
    </html>

