<?php  
    session_start();

    require_once("db_connect.php");

    $articles =[];
    $error ="";

    try{
        $pdo=db_connect();
        
        $sql=
            "SELECT 
            id,
            title,
            content,
            image,
            created_at 
            FROM articles ORDER by id DESC LIMIT 10";
        $stmt=$pdo->query($sql);

        $articles=$stmt->fetchAll(PDO::FETCH_ASSOC);
    }catch (PDOException $e){
        echo "エラーが発生しました:".($e->getMessage());
        exit;
    }

$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
?> 

   <!DOCTYPE html>  
    <html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>トップページ</title>
        <link rel="stylesheet" href="./assets/css/sanitize.css">
        <link rel="stylesheet" href="./assets/css/style.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
    <body class="<?php echo $theme_class; ?>">
            <header>
            <?php include("./includes/header.php"); ?>
            </header>
        <div id="wrapper"> 
                <div class="two-column">
                    <div class="main-content">
                        <?php if(!empty($articles)){?>
                            <?php  foreach($articles as $article){?>
                        <article class="card">
                            <?php if($article["image"]){ ?>
                                <img src="images/<?php echo ($article["image"]);?>"
                                alt="<?php echo ($article["title"]);?>:画像" class="image">   
                        <?php } ?>
                        <div class="article-content">
                            <h2 class="article-title">
                                <a href="single.php?id=<?php echo($article["id"]);?>">
                                    <?php echo ($article["title"]);?>
                                </a>
                            </h2>
                            <p class="excerpt">
                                <?php 
                                    $plain_text = strip_tags($article["content"]);
                                    $excerpt = mb_substr($plain_text, 0, 100);
                                    if (mb_strlen($plain_text) > 100) {
                                        $excerpt .= "...";
                                    } 
                                    echo htmlspecialchars($excerpt);
                                ?>
                            </p>
                            <p class="meta"><?php echo ($article["created_at"]); ?></p>
                            <p><a href="single.php?id=<?php echo($article["id"]);?>">続きを読む</a></p>
                        </div>
                            </article>
                                <?php } ?>
                            <?php } ?>
                        
                    </div>    
                    <div class="sidebar">
                         <?php include("./includes/sidebar.php"); ?>    
                    </div>     
                </div>
        </div>
            <footer>
                <?php include("./includes/footer.php"); ?>
            </footer>
            
        <script src="./assets/js/script.js"></script>   
    </body>
    </html>

