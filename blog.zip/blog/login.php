<?php

    session_start();

    require_once("db_connect.php");

    $error="";
    $user="";
    $pass="";

    if(isset($_SESSION["logged_in"])&& $_SESSION["logged_in"]===true){
        header("Location:index.php");
        exit;
}
    if($_SERVER["REQUEST_METHOD"]==="POST"){
        $user=($_POST["user"]);
        $pass=($_POST["pass"]);
        
        if(empty($user) || empty($pass)){
            $error="入力してください";
        }else{
            try{
                $pdo=db_connect();
                $sql=
                    "SELECT 
                    id,
                    user,
                    pass
                    FROM auth WHERE user=:user";
                $stmt=$pdo->prepare($sql);
                $stmt->bindvalue(":user",$user,PDO::PARAM_STR);
                $stmt->execute();

                $hash=$stmt->fetch(PDO::FETCH_ASSOC);

                    if($hash && password_verify($pass,$hash["pass"])){
                        $_SESSION["logged_in"]=true;
                        header("Location:index.php");
                        exit;
                    }else{
                        $error="ユーザ名またはパスワードが間違っています";
                    }
                    
            }catch(PDOException $e) {
                $error="接続エラー";
            }
            $pdo=null;
        }
    }
        
?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Document</title>
</head>
<body>
    <div id="wrapper">
        <h1>ログイン</h1>
        <div id="error">
            <p><?php if(!empty($error)){echo nl2br(($error));}?></p>
        </div>
            <form method="POST" action="login.php">
                <div class="login">
                    <label for="user_id">ID
                    <input type="text" name="user" id="user"><br>
                    </label>
                    <label for="pass">Password 
                    <input type="password" name="pass" id="pass"><br>
                    </label>
                    <button type="submit" class="submit_button">送信</button>
            </form>
    
</body>
</html>