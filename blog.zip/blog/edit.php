<?php
session_start();

require_once("db_connect.php");

// 1. ログイン認証の追加
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !==true) {
    header("Location:login.php");
    exit;
}

$error="";
$success="";
$title="";
$content="";
$image="";
$article = null; // 記事データを保持する変数
$article_id = null; // 記事IDを保持する変数
$existing_image = ""; // 既存の画像ファイル名を保持する変数

// 記事IDの取得と記事データの読み込み (GET/POSTどちらでも必要)
if(isset($_GET["id"]) && is_numeric($_GET["id"])){
    $article_id=(int)$_GET["id"];
} elseif (isset($_POST["id"]) && is_numeric($_POST["id"])){
    $article_id=(int)$_POST["id"];
} else {
    // IDがない場合はエラーまたはリダイレクト
    $error="記事IDが指定されていません";
    // 処理を中断
}

if ($article_id !== null) {
    try{
        $pdo=db_connect();
        
        $sql=
            "SELECT 
            id,
            title,
            content,
            image,
            created_at
            FROM articles WHERE id=:id";
        $stmt=$pdo->prepare($sql);
        $stmt->bindvalue(":id", $article_id,PDO::PARAM_INT);
        $stmt->execute();

        $article=$stmt->fetch(PDO::FETCH_ASSOC);
    
        if($article===false){  
            $error="記事が見つかりません";
            $article_id = null; // 記事が見つからなかったらIDを無効にする
        } else {
            // フォーム初期表示用にデータをセット
            $title = $article["title"];
            $content = $article["content"];
            $existing_image = $article["image"];
            $image = $existing_image; // 更新がない場合のデフォルト値
        }
    }catch(PDOException $e){
        $error="記事データの取得中にエラーが発生しました";
        $article_id = null; // エラーが発生したらIDを無効にする
    }
}

// 2. 記事更新処理 (POSTリクエスト時)
if($_SERVER["REQUEST_METHOD"]==="POST" && $article_id !== null){
    // POSTされたデータを取得
    $title = $_POST["title"];
    $content = $_POST["content"];
    $delete_image = isset($_POST["delete_image"]); // 画像削除チェックボックス

    // バリデーション
    if(empty($title)){
        $error.="タイトルは必須です\n";
    }
    if(empty($content)){
        $error.="本文は必須です\n";
    }

    // 画像ファイルの処理
    $new_image_file = !empty($_FILES["image"]["name"]);
    $upload_dir = ""; // 画像ファイル名（データベースに保存する値）

    // 既存の画像を削除する場合
    if ($delete_image) {
        $upload_dir = ""; // 画像なし
        if (!empty($existing_image)) {
            // 物理ファイルを削除
            @unlink("images/" . $existing_image);
        }
    } elseif ($new_image_file) {
        // 新しい画像がアップロードされた場合
        $file=$_FILES["image"];
        $upload_succeeded = false;
        
         try{
            if($file["error"]!== UPLOAD_ERR_OK){
                throw new RuntimeException("ファイルアップロード中にエラーが発生しました");
            }
            $max_file_size=5 * 1024 * 1024;

            if($file["size"]> $max_file_size){
                throw new RuntimeException('サイズが大きすぎます。5MB以下にしてください');
            }
            $allowed_mime_types=['image/jpeg', 'image/png', ];
            $allowed_extensions=['jpg', 'jpeg', 'png', ];

            $finfo=new finfo(FILEINFO_MIME_TYPE);
            $mime_type=$finfo->file($file["tmp_name"]);
            if(!in_array($mime_type,$allowed_mime_types,true)){
                throw new RuntimeException('許可されていないファイル形式です(MIME)');
            }

            $pathinfo=pathinfo($file["name"]);
            $extension=strtolower($pathinfo["extension"]);
            if(!in_array($extension,$allowed_extensions,true)){
                throw new RuntimeException("許可されていないファイル形式です(Extension)");
            }

            $new_file_name=uniqid("img_",true) .".".$extension;
            $upload_path="images/".$new_file_name;

            if(!is_dir("images")){
                mkdir("images",0755,true);
            }

             if (!move_uploaded_file($file['tmp_name'],$upload_path)) {
                 throw new RuntimeException('ファイルの保存に失敗しました');
            }
            
            // 新しい画像ファイル名を設定
            $upload_dir = $new_file_name;
            $upload_succeeded = true;

            // 既存の画像を削除
            if (!empty($existing_image)) {
                 @unlink("images/" . $existing_image);
            }
        } catch (RuntimeException $e) {
            $error.=$e->getMessage() . "\n";
            // アップロードが失敗した場合、既存の画像ファイル名を保持する
            $upload_dir = $existing_image;
        }
    } else {
        // 新しい画像がなく、削除もしない場合、既存の画像ファイル名を保持する
        $upload_dir = $existing_image;
    }
    
    // エラーがなければデータベースを更新
    if(empty($error)){
        try{
            // db_connect()はtryの外で実行済みなので再利用
            // $pdo=db_connect();
            
            $sql_update="
                    UPDATE  articles
                    SET title = :title,
                        content = :content,
                        image = :image
                    WHERE id = :id
                    ";
            $stmt=$pdo->prepare($sql_update);

            $stmt->bindvalue(':title',$title,PDO::PARAM_STR);
            $stmt->bindvalue(':content',$content,PDO::PARAM_STR);
            $stmt->bindvalue(':image',$upload_dir,PDO::PARAM_STR); // 新しい画像ファイル名、または既存、または空
            $stmt->bindvalue(':id',$article_id,PDO::PARAM_INT);

            $stmt->execute();

            $success="記事が正常に更新されました";
            
            // 更新後のデータを再読み込み
            $article["title"] = $title;
            $article["content"] = $content;
            $article["image"] = $upload_dir;
            $existing_image = $upload_dir; // 既存の画像ファイル名を更新
            $image = $upload_dir; // フォーム表示用の変数も更新

            // POSTリクエストが成功したらGETにリダイレクトして二重送信を防止
            // header("Location: edit.php?id=" . $article_id . "&success=1");
            // exit;

        }catch (PDOException $e){
          $error.="データベース更新中にエラーが発生しました\n";
        }
        $pdo=null; // 接続を閉じる
    }
} else if ($article_id !== null && $_SERVER["REQUEST_METHOD"] !== "POST") {
    // GETリクエスト時 (記事データを読み込んだ後)
    // $article変数の値を使ってフォームに初期値をセットする
    $title = htmlspecialchars($article["title"]);
    $content = htmlspecialchars($article["content"]);
    $existing_image = $article["image"];
}

// テーマクラスの設定 (index.phpやform.phpのロジックを流用)
$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>記事を編集: <?php echo $article ? htmlspecialchars($article["title"]) : 'エラー'; ?></title>
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="<?php echo $theme_class; ?>">
    <header>
        <?php include("./includes/header.php"); ?>
    </header>
        <div id="wrapper">
            <main>
            <div id=forms>
                <h1>記事"<?php echo $article ? htmlspecialchars($article["title"]) : ''; ?>"を編集</h1>
                    <div id="success">
                        <p><?php if(!empty($success)) {echo nl2br(htmlspecialchars($success));}?></p>
                    </div>
                    <div id="error">
                        <p><?php if(!empty($error)) {echo nl2br(htmlspecialchars($error));}?></p>
                    </div>
                <?php if ($article): ?>
                <form method="POST" action ="edit.php" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($article_id); ?>">
                    <div id="form">
                        <label for="title">タイトル</label>
                        <input class="form-title" type="text" id="title" name="title"  value="<?php echo htmlspecialchars($title); ?>"> 
                        <br>
                        <label for="content">本文</label>
                        <textarea class="form-content" id="content" name="content"  class="text-input"><?php echo htmlspecialchars($content); ?></textarea>
                        
                        <div class="current-image">
                            <?php if ($existing_image): ?>
                                <p>現在の画像:</p>
                                <img src="./images/<?php echo htmlspecialchars($existing_image); ?>" alt="現在の画像" style="max-width: 200px; height: auto;">
                                <div>
                                    <input type="checkbox" id="delete_image" name="delete_image" value="1">
                                    <label for="delete_image">画像を削除する</label>
                                </div>
                            <?php else: ?>
                                <p>現在、画像は設定されていません。</p>
                            <?php endif; ?>
                        </div>
                        
                        <label for="image">新しい画像を選択 (5MBまで)</label>
                        <input class="form-image" type="file" id="image" name="image" accept="image/png, image/jpeg, image/jpg">
                    </div>
                    <button type="submit" class="submit-button">記事を更新</button>
                </form>
                <?php endif; ?>
            </div>
        </main>
    </div>
        <footer>
            <?php include("./includes/footer.php"); ?>
        </footer>
    <script src="./assets/js/script.js"></script>    
</body>
</html>