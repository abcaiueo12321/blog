<?php
session_start();

require_once("db_connect.php");

if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !==true) {
    header("Location:login.php");
    exit;
}

$error="";
$success="";
$title="";
$content="";
$image="";
$article = null; 
$article_id = null;
$existing_image = ""; 

if(isset($_GET["id"]) && is_numeric($_GET["id"])){
    $article_id=(int)$_GET["id"];
} elseif (isset($_POST["id"]) && is_numeric($_POST["id"])){
    $article_id=(int)$_POST["id"];
} else {
    $error="記事IDが指定されていません";
}

if ($article_id !== null) {
    try{
        $pdo=db_connect();
        
        $sql=
            "SELECT 
            id,
            title,
            content,
            image,
            created_at
            FROM articles WHERE id=:id";
        $stmt=$pdo->prepare($sql);
        $stmt->bindvalue(":id", $article_id,PDO::PARAM_INT);
        $stmt->execute();

        $article=$stmt->fetch(PDO::FETCH_ASSOC);
    
        if($article===false){  
            $error="記事が見つかりません";
            $article_id = null; 
        } else {
            $title = $article["title"];
            $content = $article["content"];
            $existing_image = $article["image"];
            $image = $existing_image; 
        }
    }catch(PDOException $e){
        $error="記事データの取得中にエラーが発生しました";
        $article_id = null;
    }
}


if($_SERVER["REQUEST_METHOD"]==="POST" && $article_id !== null){
    $title = $_POST["title"];
    $content = $_POST["content"];
    $delete_image = isset($_POST["delete_image"]); 

  
    if(empty($title)){
        $error.="タイトルは必須です\n";
    }
    if(empty($content)){
        $error.="本文は必須です\n";
    }


    $new_image_file = !empty($_FILES["image"]["name"]);
    $upload_dir = ""; 

  
    if ($delete_image) {
        $upload_dir = ""; 
        if (!empty($existing_image)) {
            
            @unlink("images/" . $existing_image);
        }
    } elseif ($new_image_file) {
       
        $file=$_FILES["image"];
        $upload_succeeded = false;
        
         try{
            if($file["error"]!== UPLOAD_ERR_OK){
                throw new RuntimeException("ファイルアップロード中にエラーが発生しました");
            }
            $max_file_size=5 * 1024 * 1024;

            if($file["size"]> $max_file_size){
                throw new RuntimeException('サイズが大きすぎます。5MB以下にしてください');
            }
            $allowed_mime_types=['image/jpeg', 'image/png', ];
            $allowed_extensions=['jpg', 'jpeg', 'png', ];

            $finfo=new finfo(FILEINFO_MIME_TYPE);
            $mime_type=$finfo->file($file["tmp_name"]);
            if(!in_array($mime_type,$allowed_mime_types,true)){
                throw new RuntimeException('許可されていないファイル形式です(MIME)');
            }

            $pathinfo=pathinfo($file["name"]);
            $extension=strtolower($pathinfo["extension"]);
            if(!in_array($extension,$allowed_extensions,true)){
                throw new RuntimeException("許可されていないファイル形式です(Extension)");
            }

            $new_file_name=uniqid("img_",true) .".".$extension;
            $upload_path="images/".$new_file_name;

            if(!is_dir("images")){
                mkdir("images",0755,true);
            }

             if (!move_uploaded_file($file['tmp_name'],$upload_path)) {
                 throw new RuntimeException('ファイルの保存に失敗しました');
            }
            
            
            $upload_dir = $new_file_name;
            $upload_succeeded = true;

            if (!empty($existing_image)) {
                 @unlink("images/" . $existing_image);
            }
        } catch (RuntimeException $e) {
            $error.=$e->getMessage() . "\n";
                        $upload_dir = $existing_image;
        }
    } else {
        
        $upload_dir = $existing_image;
    }
    
    
    if(empty($error)){
        try{
            
            $sql_update="
                    UPDATE  articles
                    SET title = :title,
                        content = :content,
                        image = :image
                    WHERE id = :id
                    ";
            $stmt=$pdo->prepare($sql_update);

            $stmt->bindvalue(':title',$title,PDO::PARAM_STR);
            $stmt->bindvalue(':content',$content,PDO::PARAM_STR);
            $stmt->bindvalue(':image',$upload_dir,PDO::PARAM_STR); 
            $stmt->bindvalue(':id',$article_id,PDO::PARAM_INT);

            $stmt->execute();

            $success="記事が正常に更新されました";
            
            
            $article["title"] = $title;
            $article["content"] = $content;
            $article["image"] = $upload_dir;
            $existing_image = $upload_dir; 
            $image = $upload_dir; 

            

        }catch (PDOException $e){
          $error.="データベース更新中にエラーが発生しました\n";
        }
        $pdo=null; 
    }
} else if ($article_id !== null && $_SERVER["REQUEST_METHOD"] !== "POST") {
    $title =($article["title"]);
    $content = ($article["content"]);
    $existing_image = $article["image"];
}

$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>記事を編集: <?php echo $article ? htmlspecialchars($article["title"]) : 'エラー'; ?></title>
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="<?php echo $theme_class; ?>">
    <header>
        <?php include("./includes/header.php"); ?>
    </header>
        <div id="wrapper">
            <main>
            <div id=forms>
                <h1>記事"<?php echo $article ? htmlspecialchars($article["title"]) : ''; ?>"を編集</h1>
                    <div id="success">
                        <p><?php if(!empty($success)) {echo nl2br(htmlspecialchars($success));}?></p>
                    </div>
                    <div id="error">
                        <p><?php if(!empty($error)) {echo nl2br(htmlspecialchars($error));}?></p>
                    </div>
                <?php if ($article): ?>
                <form method="POST" action ="edit.php" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($article_id); ?>">
                    <div id="form">
                        <label for="title">タイトル</label>
                        <input class="form-title" type="text" id="title" name="title"  value="<?php echo htmlspecialchars($title); ?>"> 
                        <br>
                        <label for="content">本文</label>
                            <div class="text-toolbar">
                                <button type="button" data-tag="**" title="太字">B</button>
                                <button type="button" data-tag="*" title="斜体">I</button>
                                <button type="button" data-tag="##" title="見出し">H</button>
                            </div>
                        <textarea class="form-content" id="content" name="content"  class="text-input"><?php echo htmlspecialchars($content); ?></textarea>
                        
                        <div class="current-image">
                            <?php if ($existing_image): ?>
                                <p>現在の画像:</p>
                                <img src="./images/<?php echo htmlspecialchars($existing_image); ?>" alt="現在の画像" style="max-width: 200px; height: auto;">
                                <div>
                                    <input type="checkbox" id="delete_image" name="delete_image" value="1">
                                    <label for="delete_image">画像を削除する</label>
                                </div>
                            <?php else: ?>
                                <p>現在、画像は設定されていません。</p>
                            <?php endif; ?>
                        </div>
                        
                        <label for="image">新しい画像を選択 (5MBまで)</label>
                        <input class="form-image" type="file" id="image" name="image" accept="image/png, image/jpeg, image/jpg">
                    </div>
                    <button type="submit" class="submit-button">記事を更新</button>
                </form>
                <?php endif; ?>
            </div>
        </main>
    </div>
        <footer>
            <?php include("./includes/footer.php"); ?>
        </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./assets/js/script.js"></script>    
</body>
</html>