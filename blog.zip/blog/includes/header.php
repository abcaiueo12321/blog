<div id="header-content">
    <h1 class="site-title"><a href="index.php">11111</a></h1>
        <div class="link">
             <nav>
                    <ul>
                     <li><a href="index.php">ホーム</a></li>
                        <li><a href="form.php">投稿</a></li>
                    </ul>
                </nav>
        </div>
</div>