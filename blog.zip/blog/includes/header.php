<?php

require_once("db_connect.php");

?>
<div id="header-content">
    <h1 class="site-title"><a href="index.php">11111</a></h1>
        <div class="link">
             <nav>
                    <ul>
                     <li><a href="index.php">ホーム</a></li>
                        <li><a href="form.php">投稿</a></li>
                        <li><a href="login.php">ログイン</a></li>
                        <li><button id="darkmodetoggle" aria-label="ダークモード切替">
                                <span class="material-icons">light_mode</span>
                            </button>
                        
                    </ul>
                </nav>
        </div>
</div>