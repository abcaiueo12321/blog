<div class="footer-clock">
    <?php echo date("Y/m/d/G:i"); ?> 
</div>	
