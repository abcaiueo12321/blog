<?php
    require_once("db_connect.php");

    $categories = "";
    $error = "";

    try{
        $pdo=db_connect();
        
        $sql=
            "SELECT 
            id,
            name
            FROM categories ORDER by id";
        $stmt=$pdo->query($sql);

        $categories=$stmt->fetchAll(PDO::FETCH_ASSOC);
    }catch (PDOException $e){
        echo "エラーが発生しました:".($e->getMessage());
        exit;
    }        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <h3 class="category-title">カテゴリー</h3>
    <ul>
        <li><?php if(!empty($categories)){?>
            <?php foreach($categories as $category){?>
                <a href="category.php?id=<?php echo($category["id"]);?>">
                    <?php echo $category["name"]. "</br>";?>
            <?php } ?>
        <?php } ?>
        </li>
    </ul>
                
</body>
</html>