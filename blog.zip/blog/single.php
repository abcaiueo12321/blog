<?php
    session_start();

    require_once("db_connect.php");

    $success="";
    $error="";
    $comment_poster="";
    $comment_content="";
    
    $article = null;

    $article_category = null;
    $all_categories = [];

    if(isset($_GET["id"]) && is_numeric($_GET["id"])){
        $article_id=(int)$_GET["id"];
        
        try{
            $pdo=db_connect();
            
            $sql=
                "SELECT 
                id,
                title,
                content,
                image,
                created_at,
                category_id
                FROM articles WHERE id=:id";
            $stmt=$pdo->prepare($sql);
            $stmt->bindvalue(":id", $article_id,PDO::PARAM_INT);
            $stmt->execute();

            $article=$stmt->fetch(PDO::FETCH_ASSOC);
        
            if($article===false){  
                $error="記事が見つかりません";
            }
        }catch(PDOException $e){
            $error="エラーが発生しました";
        
        }
    }

    try{
    $pdo=db_connect();
    
 
        if ($article && $article["category_id"]) {
            $sql_category_info = "SELECT
                                id,
                                name
                                FROM categories
                                WHERE id = :category_id";
            $stmt_category_info = $pdo->prepare($sql_category_info);
            $stmt_category_info->bindValue(":category_id", $article["category_id"], PDO::PARAM_INT);
            $stmt_category_info->execute();
            $article_category = $stmt_category_info->fetch(PDO::FETCH_ASSOC);
        }

    
        $sql_all_categories = 
                            "SELECT
                            id,
                            name
                            FROM categories
                            ORDER BY name ASC";
        $stmt_all_categories = $pdo->prepare($sql_all_categories);
        $stmt_all_categories->execute();
        $all_categories = $stmt_all_categories->fetchAll(PDO::FETCH_ASSOC);
        
    }catch(PDOException $e){
    
        $error = "エラーが発生しました: " . $e->getMessage();
    }
    if($_SERVER["REQUEST_METHOD"]=="POST" && $article){
        $comment_article_id=$_POST["article_id"];
        $comment_poster=$_POST["poster"];
        $comment_content=$_POST["content"];

        
        $comment_poster = htmlspecialchars($comment_poster, ENT_QUOTES, 'UTF-8');
        $comment_content = htmlspecialchars($comment_content, ENT_QUOTES, 'UTF-8');

        if ((int)$comment_article_id === $article_id && !empty($comment_content)){

            if(empty($comment_poster)){
                $comment_poster="名無しさん";
            }

            try{
                $sql="INSERT INTO comments (article_id, poster, content, created_at) values (:article_id, :comment_poster, :comment_content,NOW())";
                $stmt=$pdo->prepare($sql);
                
                $stmt->bindvalue(':article_id',$article_id,PDO::PARAM_INT); 
                $stmt->bindvalue(':comment_poster',$comment_poster,PDO::PARAM_STR);
                $stmt->bindvalue(':comment_content',$comment_content,PDO::PARAM_STR);

                $stmt->execute();

                $success="コメントが投稿されました";
                
               
                header("Location: single.php?id=" . $article_id);
                exit;

            }catch(PDOException $e){
                $error="接続エラー";
            }
            
        } else {
         
            $comment_poster = $comment_poster;
            $comment_content = $comment_content;
            $error = "コメントを入力してください。";
        }
    }
$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $article ? htmlspecialchars($article["title"]) : '記事が見つかりません';?></title>
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="<?php echo $theme_class; ?>">
    <header>
        <?php include("./includes/header.php"); ?>
    </header>
    <div id="wrapper">
        <div class="two-column">
            <div class="main-content">
                <?php if($article):?>
                    <article class="article">
                        <h1 class="article-title"><?php echo htmlspecialchars($article["title"]);?></h1>
                        <p class="article-meta"><?php echo htmlspecialchars($article["created_at"]);?></p>
                        
                        <?php 
                        if(isset($_SESSION["logged_in"])&& $_SESSION["logged_in"]===true){
                        ?>
                        <p class="edit-link">
                            <a href="edit.php?id=<?php echo htmlspecialchars($article["id"]); ?>">
                                この記事を編集
                            </a>
                        </p>
                        <?php }; ?>
                        
                        <?php if ($article["image"]):?>
                        <div class="article-image">
                            <img src="./images/<?php echo htmlspecialchars($article["image"]);?>"
                                alt="画像" class="image">
                        </div>
                        <?php endif; ?>

                        <div class="article-content">
                            <?php echo ($article["content"]);?>
                        </div>
                    </article>
                <?php else:?>
                    <h1 class="article-title">エラーが発生しました</h1>
                    <p id="error"><?php echo htmlspecialchars($error);?></p>
                <?php endif;?>
                <?php if ($article_category): ?>
                    <div class="category">
                        <p class="linked-tags">この記事につけられたタグ:(
                            <a href="category.php?id=<?php echo htmlspecialchars($article_category["id"]); ?>">
                                    <?php echo htmlspecialchars($article_category["name"]); ?>
                            </a>)
                        </p>
                            
                            
                    </div>
                <?php endif; ?>
                <?php if($article):?>
                <div class="comment">
                    <h1>コメント</h1>
                    <?php if ($error): ?><p style="color: red;"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

                    <?php
                        try{
                        
                            $sql=
                            "SELECT 
                            poster, 
                            content, 
                            created_at
                            FROM comments WHERE article_id = ? ORDER BY created_at DESC";
                            $stmt=$pdo->prepare($sql);
                            $stmt->execute([$article_id]);
                            $comments=$stmt->fetchAll(PDO::FETCH_ASSOC);    
                            
                        }catch(PDOException $e){
                            echo "<p> コメントの読み込み中にエラーが発生しました </p>";
                            $comments=[];
                        }


                        if(empty($comments)){
                            echo "<p> コメントはありません </p>";
                        }else{
                            echo '<div class="comments">';
                            foreach ($comments as $comment){
                                $name=htmlspecialchars($comment["poster"]);
                                $text=nl2br(htmlspecialchars($comment["content"])); 
                                $date=date("Y/m/d H:i:s",  strtotime($comment["created_at"]));

                                echo '<div class="comment-contents">';
                                echo '<p>' . $name . '</p>';
                                echo '<p>' . $date . '</p>';
                                echo '<p>' . $text . '</p>';
                                echo '</div>';
                            }
                            echo '</div>';
                        }
                    ?>
                    <form action="single.php?id=<?php echo htmlspecialchars($article_id); ?>" method="post">

                    <input type="hidden" name="article_id" value="<?php echo htmlspecialchars($article_id); ?>">

                        <div>
                            <label for="poster">名前(省略可)</label>
                            <input type="text" id="poster" name="poster" maxlength="30" value="<?php echo htmlspecialchars($comment_poster); ?>">
                        </div>

                        <div>
                            <textarea id="content" name="content" required><?php echo htmlspecialchars($comment_content); ?></textarea>
                        </div>

                        <button type="submit" class="submit_button">投稿</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
            <div class="sidebar">
                <?php include("./includes/sidebar.php"); ?>    
        </div>
    </div>
        <footer>
            <?php include("./includes/footer.php"); ?>
        </footer>
        <script src="./assets/js/script.js"></script>  
</body>
</html>