<?php
    session_start();

    require_once("db_connect.php");
    
    $articles=[];
    $error="";

    if(isset($_GET["id"]) && is_numeric($_GET["id"])){
        $article_id=(int)$_GET["id"];
        
        try{
            $pdo=db_connect();
            
            $sql="SELECT id,title,content,image,created_at FROM articles WHERE id=:id";
            $stmt=$pdo->prepare($sql);
            $stmt->bindvalue(":id", $article_id,PDO::PARAM_INT);
            $stmt->execute();

            $article=$stmt->fetch(PDO::FETCH_ASSOC);
        
            if($article===false){   
                $error="記事が見つかりません";
            }
        }catch(PDOException $e){
            $error="エラーが発生しました";
        
        }
    }
            
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($article["title"]);?></title>
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <header>
        <?php include("./includes/header.php"); ?>
    </header>
    <div id="wrapper">
            <main class="main-content">
                <?php if($article):?>
                    <article class="article">
                        <h1 class="article-title"><?php echo ($article["title"]);?></h1>
                        <p class="article-meta"><?php echo ($article["created_at"]);?></p>
                        <?php if ($article["image"]):?>
                        <div class="article-image">
                            <img src="./images/<?php echo ($article["image"]);?>"
                                    alt="画像" class="image">
                        </div>
                        <?php endif; ?>

                        <div class="article-content">
                            <?php echo nl2br($article["content"]);?>
                        </div>
                    </article>
                <?php else:?>
                    <h1 class="article-title">エラーが発生しました</h1>
                    <p id="error"><?php echo($error);?></p>
                <?php endif;?>
    </div>
    <footer>
         <?php include("./includes/footer.php"); ?>
    </footer>
   
</body>
</html>