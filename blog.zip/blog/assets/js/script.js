//DarkMode//
const toggleButton = document.getElementById('darkmodetoggle');
const body = document.body;
const cookieName = 'theme';
const darkModeClass = 'dark-mode';
const lightModeIcon = 'light_mode'; 
const darkModeIcon = 'dark_mode';
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); 
        expires = "; expires=" + date.toUTCString();
    }  
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function updateIcon(isDark) {
    const iconSpan = toggleButton.querySelector('.material-icons');
    if (iconSpan) {
        iconSpan.textContent = isDark ? darkModeIcon : lightModeIcon;
    }
}
function toggleDarkMode() {
    body.classList.toggle(darkModeClass);
    const isDarkMode = body.classList.contains(darkModeClass);
    const themeValue = isDarkMode ? 'dark' : 'light';
    setCookie(cookieName, themeValue, 7);
    updateIcon(isDarkMode);
}
if (toggleButton) {
    const isDarkModeInitial = body.classList.contains(darkModeClass);
    updateIcon(isDarkModeInitial);
    toggleButton.addEventListener('click', toggleDarkMode);
}
//Decoraton//
function applyDecoration(command) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    
    let tagName = "";
    if (command === 'bold') tagName = 'B';
    if (command === 'italic') tagName = 'I';
    if (!tagName) return;

    const startNode = range.startContainer.nodeType === 3 ? range.startContainer.parentElement : range.startContainer;
    const existingTag = startNode.closest(tagName);

    if (existingTag) {
        const parent = existingTag.parentNode;
        while (existingTag.firstChild) {
            parent.insertBefore(existingTag.firstChild, existingTag);
        }
        parent.removeChild(existingTag);
    } else {
        const element = document.createElement(tagName);
        try {
            element.appendChild(range.extractContents());
            range.insertNode(element);

            const newRange = document.createRange();
            newRange.selectNodeContents(element); 
            selection.removeAllRanges();
            selection.addRange(newRange);
        } catch (e) {
            console.error("装飾できませんでした", e);
        }
    }
    selection.removeAllRanges();
    document.getElementById("form-content").focus();
}

function applyHead(){
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const startNode = range.startContainer.nodeType === 3 ? range.startContainer.parentElement : range.startContainer;
    const existingH3 = startNode.closest('H3');

    if (existingH3) {
        const parent = existingH3.parentNode;
        while (existingH3.firstChild) {
            parent.insertBefore(existingH3.firstChild, existingH3);
        }
        parent.removeChild(existingH3);
    } else {
        const h3 = document.createElement('h3');
        h3.appendChild(range.extractContents());
        range.insertNode(h3);
    }
    document.getElementById("form-content").focus();
}

function applyLink() {
    const selection = window.getSelection();
    if (!selection.rangeCount || selection.isCollapsed) return;

    const range = selection.getRangeAt(0);
    const startNode = range.startContainer.nodeType === 3 ? range.startContainer.parentElement : range.startContainer;
    
    const existingA = startNode.closest('A');

    if (existingA) {
        const parent = existingA.parentNode;
        while (existingA.firstChild) {
            parent.insertBefore(existingA.firstChild, existingA);
        }
        parent.removeChild(existingA);
    } else {
        const url = prompt("リンク先のURLを入力してください (例: https://example.com):");
        if (!url) return;

        const a = document.createElement('a');
        a.href = url;
        a.target = "_blank"; 
        a.rel = "noopener noreferrer";
        try {
            a.appendChild(range.extractContents());
            range.insertNode(a);

            const newRange = document.createRange();
            newRange.selectNodeContents(a);
            selection.removeAllRanges();
            selection.addRange(newRange);
        } catch (e) {
            console.error("リンクを作成できませんでした", e);
        }
    }
    document.getElementById("form-content").focus();
}

document.addEventListener('DOMContentLoaded', function() {
    const editor = document.getElementById('form-content');
    if (!editor) return;

    editor.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const selection = window.getSelection();
            if (!selection.rangeCount) return;

            const range = selection.getRangeAt(0);
            const startNode = range.startContainer.nodeType === 3 ? range.startContainer.parentElement : range.startContainer;
   
            const h3 = startNode.closest('h3');
            if (h3) {
                e.preventDefault();

                const newRow = document.createElement('div');
                newRow.innerHTML = '<br>'; 
                h3.parentNode.insertBefore(newRow, h3.nextSibling);
                const newRange = document.createRange();
                newRange.setStart(newRow, 0);
                newRange.collapse(true);
                selection.removeAllRanges();
                selection.addRange(newRange);
            }
        }
    });

    editor.addEventListener('paste', function(e) {});
});

document.addEventListener('DOMContentLoaded', function() {
    const editor = document.getElementById('form-content');
    if (!editor) return;

    editor.addEventListener('paste', function(e) {
        e.preventDefault();
        const text = (e.originalEvent || e).clipboardData.getData('text/plain');
        document.execCommand('insertText', false, text);
    });
});

function prepareSave() {
    const html = document.getElementById('form-content').innerHTML;
    document.getElementById('hidden-content').value = html;
}

    
    