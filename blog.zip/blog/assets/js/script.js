const toggleButton = document.getElementById('darkmodetoggle');
const body = document.body;
const cookieName = 'theme';
const darkModeClass = 'dark-mode';
const lightModeIcon = 'light_mode'; 
const darkModeIcon = 'dark_mode';
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); 
        expires = "; expires=" + date.toUTCString();
    }  
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function updateIcon(isDark) {
    const iconSpan = toggleButton.querySelector('.material-icons');
    if (iconSpan) {
        iconSpan.textContent = isDark ? darkModeIcon : lightModeIcon;
    }
}
function toggleDarkMode() {
    body.classList.toggle(darkModeClass);
    const isDarkMode = body.classList.contains(darkModeClass);
    const themeValue = isDarkMode ? 'dark' : 'light';
    setCookie(cookieName, themeValue, 7);
    updateIcon(isDarkMode);
}
if (toggleButton) {
    const isDarkModeInitial = body.classList.contains(darkModeClass);
    updateIcon(isDarkModeInitial);
    toggleButton.addEventListener('click', toggleDarkMode);
}




document.addEventListener('DOMContentLoaded', function() {
    const textarea = document.getElementById('content');
    const toolbar = document.querySelector('.text-toolbar');


    if (!textarea || !toolbar) return; 

    toolbar.addEventListener('click', function(event) {
        const button = event.target.closest('button');
        if (!button) return; 

        const tag = button.getAttribute('data-tag');
        if (!tag) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = textarea.value.substring(start, end);

        let newText = "";
        let cursorOffset = 0;
        
        if (tag === '###') {
            const lineStart = textarea.value.lastIndexOf('\n', start - 1) + 1;
            const tagWithSpace = tag + ' ';

            textarea.value = textarea.value.substring(0, lineStart) + tagWithSpace + textarea.value.substring(lineStart);
            
            cursorOffset = lineStart + tagWithSpace.length;
            
        } else {
            newText = tag + selectedText + tag;
            textarea.value = textarea.value.substring(0, start) + newText + textarea.value.substring(end);
            cursorOffset = start + newText.length;
        }

        textarea.setSelectionRange(cursorOffset, cursorOffset);
        textarea.focus();
    });
});