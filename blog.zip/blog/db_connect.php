<?php
    define("DB_USERNAME", "root");
    define("DB_PASSWORD", "");
    define("DSN", "mysql:host=localhost; dbname=blog; charset = utf8mb4");

    function db_connect(){
        $dbh = new PDO(DSN, DB_USERNAME, DB_PASSWORD);
        return $dbh;
}

    function parse_content($text){
        $text = str_replace(array("\r\n" , "\r"), "\n", $text);

        $text = preg_replace('/\*\*([^\*]+)\*\*/', '<b>$1</b>', $text);
        $text = preg_replace('/\*(?!\*)([^\*]+)\*(?!\*)/', '<i>$1</i>', $text);
        $text = mb_ereg_replace('^##\s*(.+?)\s*##?$', '<h2>\1</h2>', $text , 'm');

        

        $text = nl2br($text);
        $safe_html = strip_tags($text , '<b><br><i><h2>');

       return $safe_html;
}
?>  