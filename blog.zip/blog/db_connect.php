<?php
    define("DB_USERNAME", "root");
    define("DB_PASSWORD", "");
    define("DSN", "mysql:host=localhost; dbname=blog; charset = utf8mb4");

    function db_connect(){
        $dbh = new PDO(DSN, DB_USERNAME, DB_PASSWORD);
        return $dbh;
}
?>  