<?php

    session_start();

    require_once("db_connect.php");

    $error="";
    $category_name="";
    $category_id = null;

    if(isset($_GET["id"]) && is_numeric($_GET["id"])){
        $category_id=(int)$_GET["id"];
    }
    
        try{
            $pdo=db_connect();
            $sql_category=
                "SELECT
                id,
                name
                FROM categories WHERE id=:id";
            $stmt_category=$pdo->prepare($sql_category);
            $stmt_category->bindvalue(":id", $category_id,PDO::PARAM_INT);
            $stmt_category->execute();

            $category_info=$stmt_category->fetch();
            if(!$category_info){
                echo "存在しないカテゴリーです";
                exit;
            }

            $category_name=$category_info["name"];

            $sql_articles=
                        "SELECT
                        id,
                        title,
                        content,
                        image,
                        created_at
                        FROM articles 
                        WHERE category_id = :category_id
                        ORDER BY created_at DESC";
            $stmt_articles = $pdo->prepare($sql_articles);
            $stmt_articles->bindvalue(":category_id", $category_id, PDO::PARAM_INT);
            $stmt_articles->execute();
            $articles = $stmt_articles->fetchAll(PDO::FETCH_ASSOC);

        }catch(PDOException $e){
            echo "取得エラー. $e";
            exit;

        }   
$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
?>
 <!DOCTYPE html>
    <html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>トップページ</title>
        <link rel="stylesheet" href="./assets/css/sanitize.css">
        <link rel="stylesheet" href="./assets/css/style.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
    <body class="<?php echo $theme_class; ?>">
            <header>
            <?php include("./includes/header.php"); ?>
            </header>
        <div id="wrapper"> 
                <div class="two-column">
                    <div class="main-content">
                        <h2> カテゴリー "<?php echo htmlspecialchars($category_name) ?>"が含まれる記事</h2>
                            <?php if(!empty($articles)){?>
                            <?php  foreach($articles as $article){?>
                        <article class="card">
                            <?php if($article["image"]){ ?>
                                <img src="images/<?php echo ($article["image"]);?>"
                                alt="<?php echo ($article["title"]);?>:画像" class="image">   
                        <?php } ?>
                        <div class="article-content">
                            <h2 class="article-title">
                                <a href="single.php?id=<?php echo($article["id"]);?>">
                                    <?php echo ($article["title"]);?>
                                </a>
                            </h2>
                            <p class="excerpt">
                                <?php $excerpt=mb_substr($article["content"],0,100);
                                        if (mb_strlen($article["content"])>100){
                                            $excerpt.="...";
                                        } echo ($excerpt);
                                ?>
                            </p> 
                            <p class="meta"><?php echo ($article["created_at"]); ?></p>
                            <p><a href="single.php?id=<?php echo($article["id"]);?>">続きを読む</a></p>
                        </div>
                        </article>
                            <?php } ?>
                            <?php } ?>
                        
                            
                    </div>
                    <div class="sidebar">
                        <?php include("./includes/sidebar.php"); ?>    
                    </div>
                </div>
        </div> 
            <footer> 
            <?php include("./includes/footer.php"); ?>
            </footer>
        <script src="./assets/js/script.js"></script>        
    </body>
    </html>
        