<?php
    session_start();

    require_once("db_connect.php");
    
    if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !==true) {
    header("Location:login.php");
    }

    $error="";
    $success="";
    $title="";
    $content="";
    $image="";

    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $title= $_POST["title"];
        $content= $_POST["content"];

        if(empty($title)){
        $error.="タイトルは必須です\n";
        }
        if(empty($content)){
        $error.="本文は必須です\n";
        }

        if(empty($error) && !empty($_FILES["image"]["name"])){
        $file=$_FILES["image"];
        

         try{
            if($file["error"]!== UPLOAD_ERR_OK){
                throw new RuntimeException("ファイルアップロード中にエラーが発生しました");
            }
            $max_file_size=5 * 1024 * 1024;

            if($file["size"]> $max_file_size){
                throw new RuntimeException('サイズが大きすぎます。5MB以下にしてください');
            }
            $allowed_mime_types=['image/jpeg', 'image/png', ];
            $allowed_extensions=['jpg', 'jpeg', 'png', ];

            $finfo=new finfo(FILEINFO_MIME_TYPE);
            $mime_type=$finfo->file($file["tmp_name"]);
            if(!in_array($mime_type,$allowed_mime_types,true)){
                throw new RuntimeException('許可されていないファイル形式です(MIME)');
            }

            $pathinfo=pathinfo($file["name"]);
            $extension=strtolower($pathinfo["extension"]);
            if(!in_array($extension,$allowed_extensions,true)){
                throw new RuntimeException("許可されていないファイル形式です(Extension");
            }

            $new_file=uniqid("img_",true) .".".$extension;

            $upload_dir="images/".$new_file;
            if(!is_dir("images")){
                mkdir("images",0755,true);
            }

             if (!move_uploaded_file($file['tmp_name'],$upload_dir)) {
                 throw new RuntimeException('ファイルの保存に失敗しました');
            }
            
            $image=$new_file;
        } catch (RuntimeException $e) {
            $error.=$e->getmessage();
            }
        }
    
    if(empty($error)){
        try{
            $pdo=db_connect();
            
            $sql="insert into articles (title,content,image,created_at)values(:title,:content,:image,NOW())";
            $stmt=$pdo->prepare($sql);

            $stmt->bindvalue(':title',$title,PDO::PARAM_STR);
            $stmt->bindvalue(':content',$content,PDO::PARAM_STR);
            $stmt->bindvalue(':image',$image,PDO::PARAM_STR);

            $stmt->execute();

            $success="投稿完了";
            $title="";
            $content="";
            $image="";

        }catch (PDOException $e){
          $error="接続エラー";
        }
            

    }
    }


    


$theme_class = '';
if (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') {
    $theme_class = 'dark-mode';
}
  ?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>記事投稿</title>
    <link rel="stylesheet" href="./assets/css/sanitize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="<?php echo $theme_class; ?>">
        <header>
            <?php include("./includes/header.php"); ?>
        </header>
    <div id="wrapper">
        <main>
            <div id=forms>
                <h1>記事投稿</h1>
                    <div id="success">
                        <p><?php if(!empty($success)) {echo nl2br(htmlspecialchars($success));}?></p>
                    </div>
                    <div id="error">
                        <p><?php if(!empty($error)) {echo nl2br(htmlspecialchars($error));}?></p>
                    </div>
                <form method="POST" action ="form.php" enctype="multipart/form-data">
                    <div id="form">
                        <label for="title">タイトル</label>
                        <input class="form-title" type="text" id="title" name="title"  value="<?php echo htmlspecialchars($title); ?>"> 
                        <br>
                        <label for="content">本文</label>
                        <textarea class="form-content" id="content" name="content"  class="text-input"><?php echo htmlspecialchars($content); ?></textarea>

                        <label for="image"></label>
                        <input class="form-image" type="file" id="image" name="image" accept="image/png, image/jpeg, image/jpg">
                    </div>
                    <button type="submit" class="submit-button">投稿</button>
                </form>
            </div>
        </main>
    </div>
        <footer>
            <?php include("./includes/footer.php"); ?>
        </footer>
    <script src="./assets/js/script.js"></script>    
</body>
</html>