const toggleButton = document.getElementById('darkmodetoggle');
const body = document.body;
const cookieName = 'theme';
const darkModeClass = 'dark-mode';
const lightModeIcon = 'light_mode'; 
const darkModeIcon = 'dark_mode';
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); 
        expires = "; expires=" + date.toUTCString();
    }  
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function updateIcon(isDark) {
    const iconSpan = toggleButton.querySelector('.material-icons');
    if (iconSpan) {
        iconSpan.textContent = isDark ? darkModeIcon : lightModeIcon;
    }
}
function toggleDarkMode() {
    body.classList.toggle(darkModeClass);
    const isDarkMode = body.classList.contains(darkModeClass);
    const themeValue = isDarkMode ? 'dark' : 'light';
    setCookie(cookieName, themeValue, 7);
    updateIcon(isDarkMode);
}
if (toggleButton) {
    const isDarkModeInitial = body.classList.contains(darkModeClass);
    updateIcon(isDarkModeInitial);
    toggleButton.addEventListener('click', toggleDarkMode);
}